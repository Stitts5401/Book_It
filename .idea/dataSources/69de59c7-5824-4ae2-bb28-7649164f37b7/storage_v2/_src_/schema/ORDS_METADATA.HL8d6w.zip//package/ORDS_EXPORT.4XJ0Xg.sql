create PACKAGE ORDS_EXPORT AUTHID current_user
AS 
/**
----------------------------------------------------------------------
-- EXPORT_MODULE
----------------------------------------------------------------------
Generates the code necessary to reproduce a module and all children using the ORDS API's.
The generated script includes Roles and Privileges associated with the selected module.

@param p_module_name The module name for which to generate code.
@returns CLOB datatype containing the script text.
*/
FUNCTION EXPORT_MODULE (p_module_name in varchar2) return clob;

/**
----------------------------------------------------------------------
-- EXPORT_ALL_MODULEs
----------------------------------------------------------------------
Generates the code necessary to reproduce all modules and children using the ORDS API's.
The generated script includes all Roles and Privileges associated with the exported modules.

@returns CLOB datatype containing the script text.
*/
FUNCTION EXPORT_SCHEMA return clob;

END ORDS_EXPORT;
/

