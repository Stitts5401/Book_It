create view USER_ORDS_MODULES as
SELECT ords_modules."ID",ords_modules."NAME",ords_modules."URI_PREFIX",ords_modules."ITEMS_PER_PAGE",ords_modules."STATUS",ords_modules."COMMENTS",ords_modules."PRE_HOOK",ords_modules."SCHEMA_ID",ords_modules."CREATED_BY",ords_modules."CREATED_ON",ords_modules."UPDATED_BY",ords_modules."UPDATED_ON",
  (SELECT sec_origins_allowed_modules.origins_allowed
  FROM sec_origins_allowed_modules
  WHERE sec_origins_allowed_modules.module_id = ords_modules.id
  ) origins_allowed
FROM ords_modules,
  ords_schemas
WHERE ords_schemas.id           = ords_modules.schema_id
AND ords_schemas.parsing_schema = sys_context('USERENV', 'CURRENT_USER')
/

