create view USER_ORDS_SERVICES as
SELECT method,
  base_path,
  pattern,
  priority,
  name,
  status,
  privilege_name,
  items_per_page,
  pre_hook,
  module_id,
  template_id,
  handler_id,
  source_type,
  source
FROM
  (SELECT ORDS_MODULE_SERVICES.method,
    ORDS_MODULE_SERVICES.base_path,
    ORDS_MODULE_SERVICES.pattern,
    ORDS_MODULE_SERVICES.priority,
    ORDS_MODULE_SERVICES.name,
    ORDS_MODULE_SERVICES.status,
    ORDS_MODULE_SERVICES.privilege_name,
    ORDS_MODULE_SERVICES.items_per_page,
    ORDS_MODULE_SERVICES.pre_hook,
    ORDS_MODULE_SERVICES.module_id,
    ORDS_MODULE_SERVICES.template_id,
    ORDS_MODULE_SERVICES.handler_id,
    ORDS_MODULE_SERVICES.source_type,
    ORDS_MODULE_SERVICES.source
  FROM ORDS_MODULE_SERVICES
  WHERE ORDS_MODULE_SERVICES.owner = sys_context('USERENV', 'CURRENT_USER')
  UNION ALL
  SELECT *
  FROM
    (WITH operations AS
    (SELECT 'COLLECTION' op FROM sys.dual
    UNION ALL
    SELECT 'ITEM' FROM sys.dual
    UNION ALL
    SELECT 'CREATE' FROM sys.dual
    UNION ALL
    SELECT 'UPDATE' FROM sys.dual
    UNION ALL
    SELECT 'DELETE' FROM sys.dual
    UNION ALL
    SELECT 'DELFILTER' FROM sys.dual
    UNION ALL
    SELECT 'BATCHLOAD' FROM sys.dual
    )
  SELECT
    CASE
      WHEN op.op = 'CREATE'
      THEN 'POST'
      WHEN op.op = 'UPDATE'
      THEN 'PUT'
      WHEN op.op = 'DELETE'
      THEN 'DELETE'
      WHEN op.op = 'DELFILTER'
      THEN 'DELETE'
      WHEN op.op = 'BATCHLOAD'
      THEN 'POST'
      ELSE 'GET'
    END method,
    '/'
    || o.OBJECT_ALIAS
    || '/' base_path,
    CASE
      WHEN op.op = 'COLLECTION'
      THEN '.'
      WHEN op.op = 'CREATE'
      THEN '.'
      WHEN op.op = 'DELFILTER'
      THEN '.'
      WHEN op.op = 'BATCHLOAD'
      THEN 'batchload'
      ELSE ':id'
    END pattern,
    0 priority,
    o.PARSING_OBJECT name,
    CASE
      WHEN o.STATUS = 'DISABLED'
      THEN 'NOT_PUBLISHED'
      ELSE 'PUBLISHED'
    END status,
    NULL privilege_name,
    CASE
      WHEN op.op = 'COLLECTION'
      THEN 25
      ELSE 0
    END items_per_page,
    NVL(o.PRE_HOOK, s.pre_hook) pre_hook,
    o.ID module_id,
    CASE
      WHEN op.op = 'COLLECTION'
      THEN 0
      WHEN op.op = 'CREATE'
      THEN 0
      WHEN op.op = 'DELFILTER'
      THEN 0
      WHEN op.op = 'BATCHLOAD'
      THEN 1
      ELSE 2
    END template_id,
    o.ID handler_id,
    CASE
      WHEN op.op = 'COLLECTION'
      THEN 'object/collection'
      WHEN op.op = 'ITEM'
      THEN 'object/item'
      WHEN op.op = 'CREATE'
      THEN 'object/action;type=create'
      WHEN op.op = 'UPDATE'
      THEN 'object/action;type=update'
      WHEN op.op = 'DELETE'
      THEN 'object/action;type=delete'
      WHEN op.op = 'DELFILTER'
      THEN 'object/action;type=delete_filter'
      WHEN op.op = 'BATCHLOAD'
      THEN 'object/action;type=batch'
    END source_type,
    to_clob(o.PARSING_OBJECT) source
  FROM ords_schemas s,
    ords_objects o,
    operations op
  WHERE o.SCHEMA_ID    = s.id
  AND o.TYPE          IN ('TABLE', 'VIEW', 'MVIEW')
  AND s.parsing_schema = sys_context('USERENV', 'CURRENT_USER')
    )
  UNION ALL
  SELECT *
  FROM
    (SELECT 'POST' method,
      '/'
      || o.OBJECT_ALIAS
      || '/' base_path,
      p.procedure_name
      ||
      CASE
        WHEN p.overload IS NOT NULL
        THEN '/'
          || p.overload
        ELSE ''
      END pattern,
      0 priority,
      o.PARSING_OBJECT name,
      CASE
        WHEN o.STATUS = 'DISABLED'
        THEN 'NOT_PUBLISHED'
        ELSE 'PUBLISHED'
      END status,
      NULL privilege_name,
      0 items_per_page,
      NVL(o.pre_hook, s.pre_hook),
      o.ID module_id,
      0 + NVL(p.subprogram_id, 0) template_id,
      0 + NVL(p.overload, 0) handler_id,
      'object/execute' source_type,
      to_clob(p.OBJECT_NAME
      || '.'
      || p.PROCEDURE_NAME) source
    FROM SYS.user_procedures p,
      ORDS_METADATA.ords_schemas s,
      ORDS_METADATA.ords_objects o
    WHERE o.SCHEMA_ID     = s.id
    AND p.object_name     = o.PARSING_OBJECT
    AND p.object_type     = o.type
    AND s.parsing_schema  = sys_context('USERENV', 'CURRENT_USER')
    AND o.type            = 'PACKAGE'
    AND p.procedure_name IS NOT NULL
    )
  UNION ALL
  SELECT 'POST' method,
    '/'
    || o.OBJECT_ALIAS
    || '/' base_path,
    '.' pattern,
    0 priority,
    o.PARSING_OBJECT name,
    CASE
      WHEN o.STATUS = 'DISABLED'
      THEN 'NOT_PUBLISHED'
      ELSE 'PUBLISHED'
    END status,
    NULL privilege_name,
    0 items_per_page,
    NVL(o.PRE_HOOK, s.pre_hook) pre_hook,
    o.ID module_id,
    0 template_id,
    0 handler_id,
    'object/execute' source_type,
    to_clob(o.PARSING_OBJECT) source
  FROM ords_schemas s,
    ords_objects o
  WHERE o.SCHEMA_ID    = s.id
  AND o.TYPE          IN ('PROCEDURE', 'FUNCTION')
  AND s.parsing_schema = sys_context('USERENV', 'CURRENT_USER')
  )
ORDER BY module_id,
  template_id,
  handler_id
/

