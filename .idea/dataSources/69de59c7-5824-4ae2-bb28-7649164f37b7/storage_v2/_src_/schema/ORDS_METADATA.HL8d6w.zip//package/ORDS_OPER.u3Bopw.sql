create PACKAGE               ords_oper AUTHID CURRENT_USER
AS
  /**
   * Restrict the p_schema parameter to non null values
   */
  subtype schema_name IS ords_schemas.parsing_schema%TYPE NOT NULL;
  /**
   * Enable/disable the specified schema for ORDS access.
   *
   * @param p_enabled              True if ORDS schema access is to be enabled, othewise disabled.
   *
   * @param p_schema               The name of the schema.
   *
   * @param p_url_mapping_type     URL mapping type, Valid values: 'BASE_PATH','BASE_URL'.
   *
   * @param p_url_mapping_pattern  URL mapping pattern.
   */
  PROCEDURE enable_schema(
      p_enabled             IN boolean DEFAULT TRUE,
      p_schema              IN schema_name,
      p_url_mapping_type    IN ords_url_mappings.TYPE%TYPE DEFAULT 'BASE_PATH',
      p_url_mapping_pattern IN ords_url_mappings.pattern%TYPE DEFAULT NULL,
      p_auto_rest_auth      IN boolean DEFAULT NULL);

  /**
   * Configure how the specified schema is mapped to request URLs.
   *
   * @param p_schema               The name of the schema to map.
   *
   * @param p_url_mapping_type     URL mapping type, Valid values: 'BASE_PATH','BASE_URL'.
   *
   * @param p_url_mapping_pattern  URL mapping pattern.
   */
  PROCEDURE set_url_mapping(
      p_schema              IN schema_name,
      p_url_mapping_type    IN ords_url_mappings.TYPE%TYPE,
      p_url_mapping_pattern IN ords_url_mappings.pattern%TYPE);

END;
/

