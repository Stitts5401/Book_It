create TYPE       "security-role-ref41_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","description" VARCHAR2(4000 CHAR),"role-name" VARCHAR2(4000 CHAR),"role-link" VARCHAR2(4000 CHAR))FINAL INSTANTIABLE
/

