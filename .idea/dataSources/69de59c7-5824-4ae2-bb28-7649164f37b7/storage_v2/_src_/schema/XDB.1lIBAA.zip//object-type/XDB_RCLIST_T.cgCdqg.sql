create type     XDB$RCLIST_T                                        AS OBJECT
(
  OID    XDB$OID_LIST_T
)
/

