create TYPE         "ViewPoint3dType287_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"fadeIn" NUMBER(38),"pause" NUMBER(38),"fadeOut" NUMBER(38),"Eye" "Vector3dType288_T","Center" "Vector3dType288_T","Up" "Vector3dType288_T","Frustum3d" "Frustum3dType285_T")NOT FINAL INSTANTIABLE
/

