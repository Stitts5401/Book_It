create TYPE         "CoordinatesType245_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Coordinate" "Coordinate246_COLL")NOT FINAL INSTANTIABLE
/

