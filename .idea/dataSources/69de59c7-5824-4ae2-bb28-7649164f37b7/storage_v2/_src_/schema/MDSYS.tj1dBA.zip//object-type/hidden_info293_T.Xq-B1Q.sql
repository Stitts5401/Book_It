create TYPE         "hidden_info293_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","field" "field295_COLL")FINAL INSTANTIABLE
/

