create TYPE         "GridFileType258_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Grids" "Grids259_T")NOT FINAL INSTANTIABLE
/

