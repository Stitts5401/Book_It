create TYPE         "GridPropertiesType253_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","MinCoords" "CoordinatesType245_T","MaxCoords" "CoordinatesType245_T","CoordSpacing" "CoordinatesType245_T","CoordinateUnitOfMeasure" "UnitOfMeasureType241_T")NOT FINAL INSTANTIABLE
/

