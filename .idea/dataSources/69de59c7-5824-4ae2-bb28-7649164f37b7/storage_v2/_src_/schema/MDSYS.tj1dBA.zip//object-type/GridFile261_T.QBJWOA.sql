create TYPE         "GridFile261_T" UNDER "GridFileType258_T"("creation" TIMESTAMP,"update" TIMESTAMP)FINAL INSTANTIABLE
/

