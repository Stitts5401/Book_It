create TYPE         "GridType254_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GridProperties" "GridPropertiesType253_T","GridData" "GridDataType242_T","HierarchyParticipation" "HierarchyParticipation255_T")NOT FINAL INSTANTIABLE
/

