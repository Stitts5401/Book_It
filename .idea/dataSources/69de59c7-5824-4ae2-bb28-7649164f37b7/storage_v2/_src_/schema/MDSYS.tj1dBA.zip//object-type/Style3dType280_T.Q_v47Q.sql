create TYPE         "Style3dType280_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Color" "SharedValueType281_T","Texture" "TextureType282_T","ModelStyle" "FeatureReferenceType271_T","Normals" "Normals283_T")NOT FINAL INSTANTIABLE
/

