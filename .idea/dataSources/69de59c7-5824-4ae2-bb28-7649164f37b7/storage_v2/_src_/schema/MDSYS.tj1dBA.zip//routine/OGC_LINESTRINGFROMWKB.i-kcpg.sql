create FUNCTION OGC_LineStringFromWKB(
  wkb   IN BLOB,
  srid  IN INTEGER DEFAULT NULL)
    RETURN ST_LineString IS
BEGIN
  RETURN TREAT(ST_GEOMETRY.FROM_WKB(wkb, srid) AS ST_LineString);
END OGC_LineStringFromWKB;
/

