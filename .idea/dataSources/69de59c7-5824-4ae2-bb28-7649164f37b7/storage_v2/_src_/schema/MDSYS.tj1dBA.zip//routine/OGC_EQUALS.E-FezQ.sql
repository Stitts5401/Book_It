create FUNCTION OGC_Equals(
  g1 ST_Geometry,
  g2 ST_Geometry)
    RETURN Integer DETERMINISTIC IS
BEGIN
  RETURN g1.ST_Equals(g2);
END OGC_Equals;
/

