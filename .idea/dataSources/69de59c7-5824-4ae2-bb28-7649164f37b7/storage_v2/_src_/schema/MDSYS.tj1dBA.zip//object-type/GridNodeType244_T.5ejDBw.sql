create TYPE         "GridNodeType244_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Offset" "CoordinatesType245_T","OffsetPrecision" "CoordinatesType245_T")NOT FINAL INSTANTIABLE
/

