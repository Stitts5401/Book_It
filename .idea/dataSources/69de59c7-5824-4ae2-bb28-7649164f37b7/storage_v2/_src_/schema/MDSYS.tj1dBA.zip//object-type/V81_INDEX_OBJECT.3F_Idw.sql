create type V81_INDEX_OBJECT wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
64 89
KXdN7gcGljXRAZGUJCLju8OaEBIwg5n0dLhc5wN8X/7Sx1Lw4/6/m8Ayy8y4dCupwiFTrEzk
hpBzTHGUrHZqKl9ZLioy3ea8SvNUotaEdoTm1pQVdtZuAHbWXyF0Kio7iKY+iYjD
/

