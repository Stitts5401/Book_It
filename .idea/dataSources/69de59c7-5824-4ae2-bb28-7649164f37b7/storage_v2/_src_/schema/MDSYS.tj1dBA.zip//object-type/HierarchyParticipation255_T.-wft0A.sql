create TYPE         "HierarchyParticipation255_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Parent" "Parent256_COLL")FINAL INSTANTIABLE
/

