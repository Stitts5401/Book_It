create view APEX_APPLICATION_TEMP_CALENDAR as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.NAME                           template_name,
    t.LAST_UPDATED_BY                ,
    t.LAST_UPDATED_ON                ,
    t.THEME_ID                       theme_number,
    decode(t.THEME_CLASS_ID,
       '1','Calendar',
       '2','Calendar, Alternative 1',
       '3','Small Calendar',
       '4','Custom 1',
       '5','Custom 2',
       '6','Custom 3',
       '7','Custom 4',
       '8','Custom 5',
       '9','Custom 6',
       '10','Custom 7',
       '11','Custom 8',
       t.THEME_CLASS_ID)             theme_class,
    --
    decode(t.TRANSLATE_THIS_TEMPLATE,
      'Y','Yes','N','No','Yes')      translatable,
    --
    decode(t.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name
     from WWV_FLOW_CAL_TEMPLATES
     where id = t.REFERENCE_ID)      subscribed_from,
    --
    t.MONTH_TITLE_FORMAT             ,
    t.DAY_OF_WEEK_FORMAT             ,
    t.MONTH_OPEN_FORMAT              ,
    t.MONTH_CLOSE_FORMAT             ,
    t.DAY_TITLE_FORMAT               ,
    t.DAY_OPEN_FORMAT                ,
    t.DAY_CLOSE_FORMAT               ,
    t.TODAY_OPEN_FORMAT              ,
    t.WEEKEND_TITLE_FORMAT           ,
    t.WEEKEND_OPEN_FORMAT            ,
    t.WEEKEND_CLOSE_FORMAT           ,
    t.NONDAY_TITLE_FORMAT            ,
    t.NONDAY_OPEN_FORMAT             ,
    t.NONDAY_CLOSE_FORMAT            ,
    t.WEEK_TITLE_FORMAT              ,
    t.WEEK_OPEN_FORMAT               ,
    t.WEEK_CLOSE_FORMAT              ,
    t.DAILY_TITLE_FORMAT             ,
    t.DAILY_OPEN_FORMAT              ,
    t.DAILY_CLOSE_FORMAT             ,
    t.weekly_title_format            ,
    t.weekly_day_of_week_format      ,
    t.weekly_month_open_format       ,
    t.weekly_month_close_format      ,
    t.weekly_day_title_format        ,
    t.weekly_day_open_format         ,
    t.weekly_day_close_format        ,
    t.weekly_today_open_format       ,
    t.weekly_weekend_title_format    ,
    t.weekly_weekend_open_format     ,
    t.weekly_weekend_close_format    ,
    t.weekly_time_open_format        ,
    t.weekly_time_close_format       ,
    t.weekly_time_title_format       ,
    t.weekly_hour_open_format        ,
    t.weekly_hour_close_format       ,
    t.daily_day_of_week_format       ,
    t.daily_month_title_format       ,
    t.daily_month_open_format        ,
    t.daily_month_close_format       ,
    t.daily_day_title_format         ,
    t.daily_day_open_format          ,
    t.daily_day_close_format         ,
    t.daily_today_open_format        ,
    t.daily_time_open_format         ,
    t.daily_time_close_format        ,
    t.daily_time_title_format        ,
    t.daily_hour_open_format         ,
    t.daily_hour_close_format        ,
    t.TEMPLATE_COMMENTS              component_comment,
    t.id                             calendar_template_id,
    --
    t.NAME
    ||' t='||t.THEME_ID
    ||' c='||t.THEME_CLASS_ID
    component_signature
from WWV_FLOW_CAL_TEMPLATES t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_TEMP_CALENDAR is 'Identifies the HTML template markup used to display a Calendar'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.TEMPLATE_NAME is 'Identifies the template name'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.THEME_NUMBER is 'Identifies the numeric identifier of this theme to which this template is associated'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.THEME_CLASS is 'Identifies a specific usage for this template'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.TRANSLATABLE is 'Identifies if this component is to be identified as translatable (yes or no)'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.IS_SUBSCRIBED is 'Identifies if this Calendar Template is subscribed from another Calendar Template'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.SUBSCRIBED_FROM is 'Identifies the master component from which this component is subscribed'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.MONTH_TITLE_FORMAT is 'Format for the monthly title that appears at the top of each month'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAY_OF_WEEK_FORMAT is 'Format for the week day names which display as the column header for that day of the week'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.MONTH_OPEN_FORMAT is 'Printed immediately after the "Month Title Format". Usually this would be an HTML tag which is a container such as a table. Include substitution strings to include dynamic content.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.MONTH_CLOSE_FORMAT is 'HTML to be used to close a month'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAY_TITLE_FORMAT is 'HTML to be used for the day''s title which the first thing printed after the "Day Open Format'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAY_OPEN_FORMAT is 'HTML to be used to opening a day. This is printed for each day. Usually this would be an HTML tag which is a container such as a TD.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAY_CLOSE_FORMAT is 'HTML to be used to close a day'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.TODAY_OPEN_FORMAT is 'HTML to be used to open today. Usually this would be an HTML tag which is a container such as a td and would be different somehow from the "Day Open".'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKEND_TITLE_FORMAT is 'HTML be used to for a day occurring on a weekend'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKEND_OPEN_FORMAT is 'HTML used to open a day which is on a weekend'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKEND_CLOSE_FORMAT is 'HTML used to close a day which is on a weekend'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.NONDAY_TITLE_FORMAT is 'HTML used to format a non-day title. For example, suppose the first of a month is a Monday, but the week starts on a Sunday. Since Sunday is not be part of the current month, Sunday would be a non-day.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.NONDAY_OPEN_FORMAT is 'HTML to open a non-day'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.NONDAY_CLOSE_FORMAT is 'HTML which will close a non-day'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEK_TITLE_FORMAT is 'HTML be used to for a day occurring on a weekend'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEK_OPEN_FORMAT is 'HTML to be used to open a week. This is printed for each week. Usually this would be an HTML tag which is a container such as a TR.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEK_CLOSE_FORMAT is 'HTML to be used to close a week.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_TITLE_FORMAT is 'Format for the weekly title that appears at the top of each week'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_DAY_OF_WEEK_FORMAT is 'Format for the week day names which display as the column header for that day of the Week'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_MONTH_OPEN_FORMAT is 'Printed immediately after the "Week Title Format". Usually this would be an HTML tag which is a container such as a table. Include substitution strings to include dynamic content.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_MONTH_CLOSE_FORMAT is 'HTML to be used to close a Week'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_DAY_TITLE_FORMAT is 'HTML to be used for the day''s title which the first thing printed after the "Day Open Format'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_DAY_OPEN_FORMAT is 'HTML to be used to opening a day. This is printed for each day. Usually this would be an HTML tag which is a container such as a TD.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_DAY_CLOSE_FORMAT is 'HTML to be used to close a day'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_TODAY_OPEN_FORMAT is 'HTML to be used to open today. Usually this would be an HTML tag which is a container such as a td and would be different somehow from the "Day Open".'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_WEEKEND_TITLE_FORMAT is 'HTML be used to for a day occurring on a weekend'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_WEEKEND_OPEN_FORMAT is 'HTML used to open a day which is on a weekend'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_WEEKEND_CLOSE_FORMAT is 'HTML used to close a day which is on a weekend'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_TIME_OPEN_FORMAT is 'HTML to be used to display the Time. This is printed for each Hour for a week. Usually this would be an HTML tag which is a container such as a TD.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_TIME_CLOSE_FORMAT is 'HTML to be used to close the Time display column'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_TIME_TITLE_FORMAT is 'HTML be used for displaying the Time'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_HOUR_OPEN_FORMAT is 'HTML to be used to opening the Hour for the week. This is printed for each Hour. Usually this would be an HTML tag which is a container such as a TR.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.WEEKLY_HOUR_CLOSE_FORMAT is 'HTML to be used to close the Hour'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_DAY_OF_WEEK_FORMAT is 'Format for the week day names which display as the column header for that day of the Week'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_MONTH_TITLE_FORMAT is 'Title format for the Daily Calendar.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_MONTH_OPEN_FORMAT is 'Printed immediately after the "Day Title Format". Usually this would be an HTML tag which is a container such as a table. Include substitution strings to include dynamic content.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_MONTH_CLOSE_FORMAT is 'HTML to be used to close a Day'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_DAY_TITLE_FORMAT is 'HTML to be used for the day''s title which the first thing printed after the "Day Open Format'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_DAY_OPEN_FORMAT is 'HTML to be used to opening a day. This is printed for each day. Usually this would be an HTML tag which is a container such as a TD.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_DAY_CLOSE_FORMAT is 'HTML to be used to close a day'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_TODAY_OPEN_FORMAT is 'HTML to be used to open today. Usually this would be an HTML tag which is a container such as a td and would be different somehow from the "Day Open".'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_TIME_OPEN_FORMAT is 'HTML to be used to display the Time. This is printed for each Hour. Usually this would be an HTML tag which is a container such as a TD.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_TIME_CLOSE_FORMAT is 'HTML to be used to close the Time display column'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_TIME_TITLE_FORMAT is 'HTML be used for displaying the Time'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_HOUR_OPEN_FORMAT is 'HTML to be used to opening the Hour for the Day. This is printed for each Hour. Usually this would be an HTML tag which is a container such as a TR.'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.DAILY_HOUR_CLOSE_FORMAT is 'HTML to be used to close the Hour'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.CALENDAR_TEMPLATE_ID is 'Identifies the Primary Key of this Calendar Template'
/

comment on column APEX_APPLICATION_TEMP_CALENDAR.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

