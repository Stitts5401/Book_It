create package wwv_flow_application_install as

--  Copyright (c) Oracle Corporation 2010. All Rights Reserved.
--
--    NAME
--      wwv_flow_application_install
--
--    DESCRIPTION
--      Methods used to control APEX application installation behavior.  If not set,
--      then an APEX application will install normally.  However, if these global are set,
--      then these will take precedence over those specified in the application export file
--
--
--
--
--

--
-- Workspace ID
--
procedure set_workspace_id(
    p_workspace_id in number );

function get_workspace_id
    return number;


--
-- Application ID
--
procedure set_application_id(
    p_application_id in number );

function get_application_id
    return number;

procedure generate_application_id;


--
-- Offset
--
procedure set_offset(
    p_offset in number );

procedure generate_offset;

function get_offset
    return number;


--
-- Schema
--
procedure set_schema(
    p_schema in varchar2 );

function get_schema
    return varchar2;


--
-- Name
--
procedure set_application_name(
    p_application_name in varchar2 );

function get_application_name
    return varchar2;


--
-- Alias
--
procedure set_application_alias(
    p_application_alias in varchar2 );

function get_application_alias
    return varchar2;


--
-- Image Prefix
--
procedure set_image_prefix(
    p_image_prefix in varchar2 );

function get_image_prefix
    return varchar2;


--
-- Proxy
--
procedure set_proxy(
    p_proxy in varchar2 );

function get_proxy
    return varchar2;



--
-- Clear
--
procedure clear_all;



end wwv_flow_application_install;
/

