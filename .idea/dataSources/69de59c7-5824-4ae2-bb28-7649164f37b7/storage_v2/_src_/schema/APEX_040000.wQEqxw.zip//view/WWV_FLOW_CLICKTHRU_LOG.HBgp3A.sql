create view WWV_FLOW_CLICKTHRU_LOG as
select clickdate, category, id, flow_user, ip
      from wwv_flow_clickthru_log_v
     where security_group_id = (select wwv_flow.get_sgid from dual)
/

