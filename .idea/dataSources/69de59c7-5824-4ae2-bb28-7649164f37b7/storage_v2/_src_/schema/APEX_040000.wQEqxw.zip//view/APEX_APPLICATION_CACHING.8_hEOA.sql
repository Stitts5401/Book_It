create view APEX_APPLICATION_CACHING as
select
    w.short_name                                        workspace,
    f.ID                                                application_id,
    f.NAME                                              application_name,
    decode(c.region_id,null,c.PAGE_ID,
    (select page_id from wwv_flow_page_plugs
     where id = c.region_id and flow_id = c.flow_id))   page_id,
    (select name
     from wwv_flow_steps
     where id in
     decode(c.region_id,null,c.PAGE_ID,
    (select page_id from wwv_flow_page_plugs
     where id = c.region_id and flow_id = c.flow_id))
      and  flow_id = f.id)                              page_name,
    decode(decode(chart_region_id,null,
    'X','Chart Region Cache'),'X',
    decode(region_id,null,'Page Cache','Region Cache')) cache_type,
    c.LANGUAGE                                          language,
    c.USER_NAME                                         caching_user,
    dbms_lob.getlength(c.PAGE_TEXT)                     cache_size,
    decode(region_id,null,null,
    (select plug_name
     from wwv_flow_page_plugs
     where id = c.region_id and flow_id = f.id))        region_name,
    c.CACHED_ON                                         cached_on,
    decode(region_id,null,
    (select cache_timeout_seconds
     from wwv_flow_steps
     where flow_id = f.id and id = c.page_id),
    (select PLUG_CACHING_MAX_AGE_IN_SEC
     from wwv_flow_page_plugs
     where id = c.region_id))                           cached_for_seconds,
    --
    round((sysdate - c.cached_on) * 3600 * 24,0)        age_in_seconds,
    --
    decode(region_id,null,
    (select cache_timeout_seconds -
             round((sysdate - c.cached_on)
             * 3600 * 24,0) a
     from wwv_flow_steps
     where flow_id = f.id and id = c.page_id),
    (select PLUG_CACHING_MAX_AGE_IN_SEC -
            round((sysdate - c.cached_on)
            * 3600 * 24,0) a
     from wwv_flow_page_plugs
     where id = c.region_id))                           timeout_in_seconds,
    c.REGION_ID                                         region_id,
    c.SECURITY_GROUP_ID                                 workspace_id
from
     wwv_flow_page_cache c,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      c.flow_id = f.id and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      f.security_group_id = s.SECURITY_GROUP_ID and
      s.schema = f.owner and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_CACHING is 'Applications defined in the current workspace or database user.'
/

comment on column APEX_APPLICATION_CACHING.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_CACHING.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_CACHING.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_CACHING.PAGE_ID is 'Identifies page number'
/

comment on column APEX_APPLICATION_CACHING.PAGE_NAME is 'Identifies page name'
/

comment on column APEX_APPLICATION_CACHING.CACHE_TYPE is 'Cache type, Page, Region, or Chart Region'
/

comment on column APEX_APPLICATION_CACHING.LANGUAGE is 'Language of Cache'
/

comment on column APEX_APPLICATION_CACHING.CACHING_USER is 'User who caused the page or region to be cached'
/

comment on column APEX_APPLICATION_CACHING.CACHE_SIZE is 'Size of the cache, sum this column to see full cache size'
/

comment on column APEX_APPLICATION_CACHING.REGION_NAME is 'Identifies region name, null for page caches'
/

comment on column APEX_APPLICATION_CACHING.CACHED_ON is 'Date cache was created'
/

comment on column APEX_APPLICATION_CACHING.CACHED_FOR_SECONDS is 'Iimeout in seconds identified in page or region caching meta data'
/

comment on column APEX_APPLICATION_CACHING.AGE_IN_SECONDS is 'Seconds elapsed since cache was created'
/

comment on column APEX_APPLICATION_CACHING.TIMEOUT_IN_SECONDS is 'Seconds until cache will expire.  Negitive values indicate an expired cache'
/

comment on column APEX_APPLICATION_CACHING.REGION_ID is 'Corresponding primary key of region'
/

comment on column APEX_APPLICATION_CACHING.WORKSPACE_ID is 'Corresponding primary key of workspace'
/

