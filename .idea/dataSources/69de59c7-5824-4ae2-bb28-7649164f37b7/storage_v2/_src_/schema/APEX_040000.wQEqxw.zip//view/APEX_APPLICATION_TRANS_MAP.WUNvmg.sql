create view APEX_APPLICATION_TRANS_MAP as
select f.workspace                      workspace,
       m.ID                             map_id,
       m.primary_language_flow_id       primary_application_id,
       f.application_name               primary_application_name,
       m.translation_flow_id            translated_application_id,
       m.translation_flow_language_code translated_app_language,
       m.translation_image_directory    translated_appl_img_dir,
       m.translation_comments           translation_comments,
       m.map_comments                   translation_map_comments,
       m.last_updated_by,
       m.last_updated_on,
       m.created_by,
       m.created_on
  from wwv_flow_authorized f,
       wwv_flow_language_map m
 where m.primary_language_flow_id = f.application_id
/

comment on table APEX_APPLICATION_TRANS_MAP is 'Application Groups defined per workspace.  Applications can be associated with an application group.'
/

comment on column APEX_APPLICATION_TRANS_MAP.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TRANS_MAP.MAP_ID is 'Unique ID that identifies this translation mapping'
/

comment on column APEX_APPLICATION_TRANS_MAP.PRIMARY_APPLICATION_ID is 'Unique ID of the application that is the target of the translation'
/

comment on column APEX_APPLICATION_TRANS_MAP.PRIMARY_APPLICATION_NAME is 'Name of the application that is the target of the translation'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATED_APPLICATION_ID is 'Unique ID of the translated application'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATED_APP_LANGUAGE is 'Language code, for example "fr" or "pt-br"'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATED_APPL_IMG_DIR is 'Optional directory of translated images'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATION_COMMENTS is 'Comments associated with this translation'
/

comment on column APEX_APPLICATION_TRANS_MAP.TRANSLATION_MAP_COMMENTS is 'Comments associated with this mapping'
/

comment on column APEX_APPLICATION_TRANS_MAP.LAST_UPDATED_BY is 'Last user to update this translation mapping'
/

comment on column APEX_APPLICATION_TRANS_MAP.LAST_UPDATED_ON is 'Date of last update to this translation mapping'
/

comment on column APEX_APPLICATION_TRANS_MAP.CREATED_BY is 'User that created this translation mapping'
/

comment on column APEX_APPLICATION_TRANS_MAP.CREATED_ON is 'Date this translation mapping was created'
/

