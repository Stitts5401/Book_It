create function nv (
    p_item in varchar2)
    return number
--  Copyright (c) Oracle Corporation 1999. All Rights Reserved.
--
--    DESCRIPTION
--      Function to return a numeric flow value.  V stands for value.
--
--    SECURITY
--
--    NOTES
--
is
begin
    return to_number(replace(v(p_item), wwv_flow.get_nls_group_separator, null));
end nv;
/

