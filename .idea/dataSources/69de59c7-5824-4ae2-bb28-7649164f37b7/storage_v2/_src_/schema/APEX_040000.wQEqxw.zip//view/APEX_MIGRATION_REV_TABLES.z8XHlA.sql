create view APEX_MIGRATION_REV_TABLES as
select
        a.project_id                                    project_id,
     --
        d.migration_name                                project_name,
     --
        d.migration_type                                migration_type,
     --
        a.dbid                                          dbid,
     --
        f.tblid                                         table_id,
     --
        f.orig_table_name                               orig_table_name,
     --
        f.mig_table_name                                mig_table_name,
     --
        f.owner                                         owner,
     --
        f.status                                        status,
     --
        f.primarykey_name                               primarykey_name,
     --
        f.created_on                                    created_on,
     --
        f.created_by                                    created_by,
     --
        a.last_updated_on                               last_updated_on,
     --
        a.last_updated_by                               last_updated_by,
     --
	s.schema                                        schema,
     --
	w.short_name                                    workspace,
     --
	w.provisioning_company_id                       workspace_id
     --
from
        wwv_mig_access a,
     --
        wwv_mig_rev_tables f,
     --
        wwv_flow_company_schemas s,
     --
        wwv_mig_projects d,
     --
        wwv_flow_companies w,
     --
        (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) g
     --
where
        (s.schema = user or user in ('SYS','SYSTEM','APEX_040000') or g.sgid = w.PROVISIONING_COMPANY_ID)
and     w.PROVISIONING_COMPANY_ID != 0
and     a.database_schema = s.schema
and     a.project_id = d.id
and     a.security_group_id = d.security_group_id
and     f.security_group_id = a.security_group_id
and     f.project_id = a.project_id
and     f.dbid = a.dbid
and     w.provisioning_company_id = a.security_group_id
and     w.provisioning_company_id = s.security_group_id
order by w.provisioning_company_id, f.project_id, f.tblid, f.dbid
/

comment on table APEX_MIGRATION_REV_TABLES is 'Available Application Express (Apex) Application Migrations Migration Projects'
/

comment on column APEX_MIGRATION_REV_TABLES.PROJECT_ID is 'Primary key that identifies the migration project'
/

comment on column APEX_MIGRATION_REV_TABLES.PROJECT_NAME is 'Identifies name of the migration project'
/

comment on column APEX_MIGRATION_REV_TABLES.MIGRATION_TYPE is 'Identifies the type of Migration Project'
/

comment on column APEX_MIGRATION_REV_TABLES.DBID is 'Identifies the unique number of the original MS Access database'
/

comment on column APEX_MIGRATION_REV_TABLES.TABLE_ID is 'Identifies the unique number of the original MS Access table'
/

comment on column APEX_MIGRATION_REV_TABLES.ORIG_TABLE_NAME is 'Identifies the name of the original MS Access table'
/

comment on column APEX_MIGRATION_REV_TABLES.MIG_TABLE_NAME is 'Identifies the name of the migrated table associated with the MS Access table'
/

comment on column APEX_MIGRATION_REV_TABLES.OWNER is 'Identifies the owner of the original MS Access table'
/

comment on column APEX_MIGRATION_REV_TABLES.STATUS is 'Identifies the status of the migrated table: valid or invalid based upon existence of a primary key on the table'
/

comment on column APEX_MIGRATION_REV_TABLES.PRIMARYKEY_NAME is 'Identifies the name of the primary key'
/

comment on column APEX_MIGRATION_REV_TABLES.CREATED_ON is 'Identifies the name of the user who created the original MS Access database'
/

comment on column APEX_MIGRATION_REV_TABLES.CREATED_BY is 'Identifies the name of the user who created the original MS Access database'
/

comment on column APEX_MIGRATION_REV_TABLES.LAST_UPDATED_ON is 'Date of most recent changes to the Migration Project'
/

comment on column APEX_MIGRATION_REV_TABLES.LAST_UPDATED_BY is 'Identifies the APEX User Name who last modified the Migration Project'
/

