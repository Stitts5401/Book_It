create view APEX_TEAM_MILESTONES as
select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
	m.ID                        milestone_id,
	m.EVENT_NAME                milestone,
	m.EVENT_OWNER               milestone_owner,
	m.EVENT_DATE                milestone_date,
	m.EVENT_TYPE                milestone_type,
	m.RELEASE                   release,
	m.EVENT_DESC                milestone_description,
	m.TAGS                      tags,
	--
	m.CREATED_BY,
	m.CREATED_ON,
	m.UPDATED_BY,
	m.UPDATED_ON,
	m.EVENT_ID                  friendly_milestone_id,
	m.SELECTABLE_FROM_FEATURES_YN
from
    WWV_FLOW_EVENTS m,
    wwv_flow_companies w
where
    m.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_TEAM_MILESTONES is 'Identifies bugs, also known as software defects.'
/

comment on column APEX_TEAM_MILESTONES.WORKSPACE_ID is 'Primary key that identifies the workspace.'
/

comment on column APEX_TEAM_MILESTONES.WORKSPACE_NAME is 'Name of the workspace.'
/

comment on column APEX_TEAM_MILESTONES.MILESTONE_ID is 'Primary key of the bug.'
/

comment on column APEX_TEAM_MILESTONES.MILESTONE is 'Name of the milestone.'
/

comment on column APEX_TEAM_MILESTONES.MILESTONE_OWNER is 'Owner of the milestone.'
/

comment on column APEX_TEAM_MILESTONES.MILESTONE_DATE is 'Date on which the milestone is to occur.'
/

comment on column APEX_TEAM_MILESTONES.MILESTONE_TYPE is 'Type of milestone.'
/

comment on column APEX_TEAM_MILESTONES.RELEASE is 'Release milestone is associated with.'
/

comment on column APEX_TEAM_MILESTONES.MILESTONE_DESCRIPTION is 'Description of milestone.'
/

comment on column APEX_TEAM_MILESTONES.TAGS is 'Tags associated with this milestone.'
/

comment on column APEX_TEAM_MILESTONES.CREATED_BY is 'Developer who created this milestone.'
/

comment on column APEX_TEAM_MILESTONES.CREATED_ON is 'Date on which this milestone was created.'
/

comment on column APEX_TEAM_MILESTONES.UPDATED_BY is 'Developer who last updated this milestone.'
/

comment on column APEX_TEAM_MILESTONES.UPDATED_ON is 'Date on which this milestone was last updated.'
/

comment on column APEX_TEAM_MILESTONES.FRIENDLY_MILESTONE_ID is 'More readable id for the milestone (unique within workspace only).'
/

comment on column APEX_TEAM_MILESTONES.SELECTABLE_FROM_FEATURES_YN is 'Identifies whether or not this milestone can be associated with a feature.'
/

