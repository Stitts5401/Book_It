create package wwv_flow_plugin_util
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2009. All Rights Reserved.
--
--    NAME
--      wwv_flow_plugin_util.sql
--
--    DESCRIPTION
--      This package is a collection of utility functions for plug-ins.
--
--    RUNTIME DEPLOYMENT: YES
--
--    MODIFIED   (MM/DD/YYYY)
--    pawolf      02/03/2010 - Created
--    pawolf      02/09/2010 - Added print_hidden_protected
--    pawolf      02/20/2010 - Added support for process plugins
--    pawolf      03/04/2010 - Added p_escape to print_option
--    pawolf      03/08/2010 - Added pagination support to prepare_query and get_data
--    pawolf      03/18/2010 - Added page_item_names_to_jQuery
--    pawolf      04/14/2010 - Added name to t_column_values
--    pawolf      04/15/2010 - Added get_plsql_expression_result, get_plsql_function_result and execute_plsql_code
--    pawolf      08/23/2010 - Bug# 10041505: Add LIKE operation for prepare_query and get_search_string
--    pawolf      08/27/2010 - Bug# 10024385: added cleanup_page_item_names
--    pawolf      08/29/2010 - Bug# 10157646: added is_component_used
--
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Public type definitions
--------------------------------------------------------------------------------
type t_sql_handler is record (
    cursor_handler     number,
    base_statement     varchar2(32767),
    column_list        sys.dbms_sql.desc_tab2,
    bind_variable_list wwv_flow_global.vc_arr2 );

type t_value is record (
    varchar2_value      varchar2(32767),
    number_value        number,
    date_value          date,
    timestamp_value     timestamp,
    timestamp_tz_value  timestamp with time zone,
    timestamp_ltz_value timestamp with local time zone,
    interval_y2m_value  interval year to month,
    interval_d2s_value  interval day to second,
    blob_value          blob,
    bfile_value         bfile,
    clob_value          clob );

type t_value_list is table of t_value index by pls_integer;

type t_column_values is record (
    name       varchar2(30),
    data_type  varchar2(20), /* use c_data_type_* constants to compare */
    value_list t_value_list );

type t_column_value_list  is table of wwv_flow_global.vc_arr2 index by pls_integer;
type t_column_value_list2 is table of t_column_values         index by pls_integer;

--------------------------------------------------------------------------------
-- Public constant definitions
--------------------------------------------------------------------------------
c_search_contains_case    constant varchar2(20) := 'CONTAINS_CASE';   -- uses INSTR
c_search_contains_ignore  constant varchar2(20) := 'CONTAINS_IGNORE'; -- uses INSTR with UPPER
c_search_exact_case       constant varchar2(20) := 'EXACT_CASE';      -- uses LIKE value%
c_search_exact_ignore     constant varchar2(20) := 'EXACT_IGNORE';    -- uses LIKE VALUE% with UPPER
c_search_like_case        constant varchar2(20) := 'LIKE_CASE';       -- uses LIKE %value%
c_search_like_ignore      constant varchar2(20) := 'LIKE_IGNORE';     -- uses LIKE %VALUE% with UPPER
c_search_lookup           constant varchar2(20) := 'LOOKUP';          -- uses = value
--
c_data_type_varchar2      constant varchar2(20) := 'VARCHAR2';
c_data_type_number        constant varchar2(20) := 'NUMBER';
c_data_type_date          constant varchar2(20) := 'DATE';
c_data_type_timestamp     constant varchar2(20) := 'TIMESTAMP';
c_data_type_timestamp_tz  constant varchar2(20) := 'TIMESTAMP_LZ';
c_data_type_timestamp_ltz constant varchar2(20) := 'TIMESTAMP_LTZ';
c_data_type_interval_y2m  constant varchar2(20) := 'INTERVAL_Y2M';
c_data_type_interval_d2s  constant varchar2(20) := 'INTERVAL_D2S';
c_data_type_blob          constant varchar2(20) := 'BLOB';
c_data_type_bfile         constant varchar2(20) := 'BFILE';
c_data_type_clob          constant varchar2(20) := 'CLOB';
--
c_empty_data_type_list    wwv_flow_global.vc_arr2;
--
--==============================================================================
-- Returns p_value escaped or not depending on the escape parameter.
--==============================================================================
function escape (
    p_value  in varchar2,
    p_escape in boolean )
    return varchar2;
--
--==============================================================================
-- Returns TRUE if both values are equal and FALSE if not.
-- Note: if both values are null, TRUE will be returned as well.
--==============================================================================
function is_equal (
    p_value1 in varchar2,
    p_value2 in varchar2 )
    return boolean;
--
--==============================================================================
-- Returns the position in the list where p_value is stored. If it's not found
-- null will be returned.
--==============================================================================
function get_position_in_list (
    p_list  in wwv_flow_global.vc_arr2,
    p_value in varchar2 )
    return number;
--
--==============================================================================
-- Outputs the value in an escaped form. It's also taking care of chunking big
-- strings into smaller outputs.
--==============================================================================
procedure print_escaped_value (
    p_value in varchar2 );
--
--==============================================================================
-- Outputs a hidden field to store the page item value if the
-- page item is rendered readonly but not printer friendly
--==============================================================================
procedure print_hidden_if_readonly (
    p_item_name           in varchar2,
    p_value               in varchar2,
    p_is_readonly         in boolean,
    p_is_printer_friendly in boolean,
    p_id_postfix          in varchar2 default null );
--
--==============================================================================
-- Outputs a hidden protected field to store the page item value.
--==============================================================================
procedure print_hidden_protected (
    p_item_name  in varchar2,
    p_value      in varchar2,
    p_id_postfix in varchar2 default null );
--
--==============================================================================
-- Outputs a SPAN tag for a display only field.
--==============================================================================
procedure print_display_only (
    p_item_name        in varchar2,
    p_display_value    in varchar2,
    p_show_line_breaks in boolean,
    p_escape           in boolean,
    p_attributes       in varchar2,
    p_id_postfix       in varchar2 default '_DISPLAY' );
--
--==============================================================================
-- Outputs an OPTION tag. The values are always escaped.
--==============================================================================
procedure print_option (
    p_display_value in varchar2,
    p_return_value  in varchar2,
    p_is_selected   in boolean,
    p_attributes    in varchar2,
    p_escape        in boolean  default true );
--
--==============================================================================
-- Outputs the standard HTTP header for a JSON output.
--==============================================================================
procedure print_json_http_header;
--
--==============================================================================
-- Outputs a JSON response based on the result of a two column LOV in the format:
-- [{"d":"display","r":"return"},{"d":...,"r":...},...]
--
-- p_component_name is the name of the page item or report column, ... which is
--                  used in case an error has to be displayed.
--
-- Note: The HTTP header is initialized with mime type "application/json" as well
--==============================================================================
procedure print_lov_as_json (
    p_sql_statement      in varchar2,
    p_component_name     in varchar2,
    p_escape             in boolean,
    p_support_legacy_lov in boolean default false /* for internal use only! */
    );
--
--==============================================================================
-- Returns a Javascript array with all the page items which are really on the
-- current and on page 0. p_bind_variable_list are the bind variables returned
-- by wwv_flow_utilities.get_binds
--==============================================================================
function get_depending_fields (
    p_bind_variable_list in wwv_flow_global.vc_arr2 )
    return varchar2;
--
--==============================================================================
-- Returns a jQuery selector based on a comma delimited string of page item names.
--==============================================================================
function page_item_names_to_jquery (
    p_page_item_names in varchar2 )
    return varchar2;
--
--==============================================================================
-- Returns a cleaned up version of a comma delimited string of page item names
-- where all spaces are removed, colons are replaced with a comma and the
-- page item names are converted to uppercase.
-- This is important for JavaScript code, because page item names are
-- case sensitive in the browser.
--==============================================================================
function cleanup_page_item_names (
    p_page_item_names in varchar2 )
    return varchar2;
--
--==============================================================================
-- Executes the query restricted by search string (optional) and returns the
-- values for each column.
-- Note: All column values are returned as a string, independent of there
--       data type!
--
-- p_sql_statement:    SQL statement which should be executed.
-- p_min_columns and
-- p_max_columns:      Used to check if the SQL statement complies to the number
--                     of required columns.
-- p_component_name:   The name of the page item or report column, ... which is
--                     used in case an error has to be displayed.
-- p_search_type:      Use one of the c_search_* constants.
-- p_search_column_no: Column which should be used to restrict the SQL statement.
--                     Has to be in range of p_min_column and p_max_column.
-- p_search_string:    Value which should be used to restrict the query.
-- p_first_row:        Skips all rows before the specified row. Can be used for
--                     pagination.
-- p_max_rows:         Limits the number of returned rows.
--==============================================================================
function get_data (
    p_sql_statement      in varchar2,
    p_min_columns        in number,
    p_max_columns        in number,
    p_component_name     in varchar2,
    p_search_type        in varchar2 default null,
    p_search_column_no   in varchar2 default 2,
    p_search_string      in varchar2 default null,
    p_first_row          in number   default null,
    p_max_rows           in number   default null,
    p_support_legacy_lov in boolean  default false  /* for internal use only! */ )
    return t_column_value_list;
--
--==============================================================================
-- Executes the query restricted by search string (optional) and returns the
-- values for each column. This is a more advanced version of get_data, because
-- it returns the column values with there original data types.
--
-- p_sql_statement:    SQL statement which should be executed.
-- p_min_columns and
-- p_max_columns:      Used to check if the SQL statement complies to the number
--                     of required columns.
-- p_data_type_list:   If provided checks that the data type for each column
--                     matches to the specified data type in the array.
--                     Use the constants c_data_type_* for available data types.
-- p_component_name:   The name of the page item or report column, ... which is
--                     used in case an error has to be displayed.
-- p_search_type:      Use one of the c_search_* constants.
-- p_search_column_no: Column which should be used to restrict the SQL statement.
--                     Has to be in range of p_min_column and p_max_column.
-- p_search_string:    Value which should be used to restrict the query.
-- p_first_row:        Skips all rows before the specified row. Can be used for
--                     pagination.
-- p_max_rows:         Limits the number of returned rows.
--==============================================================================
function get_data2 (
    p_sql_statement    in varchar2,
    p_min_columns      in number,
    p_max_columns      in number,
    p_data_type_list   in wwv_flow_global.vc_arr2 default c_empty_data_type_list,
    p_component_name   in varchar2,
    p_search_type      in varchar2 default null,
    p_search_column_no in varchar2 default 2,
    p_search_string    in varchar2 default null,
    p_first_row        in number   default null,
    p_max_rows         in number   default null )
    return t_column_value_list2;
--
--==============================================================================
-- Gets the display (lookup) value for the value specified in p_search_string.
--
-- p_sql_statement:     SQL statement which is used for the lookup.
-- p_min_columns and
-- p_max_columns:       Used to check if the SQL statement complies to the number
--                      of required columns.
-- p_component_name:    The name of the page item or report column, ... which is
--                      used in case an error has to be displayed.
-- p_display_column_no: Column which should be returned from the SQL statement.
--                      Has to be in range of p_min_column and p_max_column.
-- p_search_column_no:  Column which should be used to restrict the SQL statement.
--                      Has to be in range of p_min_column and p_max_column.
-- p_search_string:     Value which should be looked up.
-- p_display_extra:     If set to TRUE and a value isn't found, the search value
--                      will be added to the result instead.
--
-- Note: In the case multiple rows are returned by the query, just the first one
--       is returned.
--==============================================================================
function get_display_data (
    p_sql_statement      in varchar2,
    p_min_columns        in number,
    p_max_columns        in number,
    p_component_name     in varchar2,
    p_display_column_no  in binary_integer default 1,
    p_search_column_no   in binary_integer default 2,
    p_search_string      in varchar2,
    p_display_extra      in boolean        default true,
    p_support_legacy_lov in boolean        default false /* for internal use only! */ )
    return varchar2;
--
--==============================================================================
-- Gets the display (lookup) values for the values specified in p_search_value_list.
--
-- p_sql_statement:     SQL statement which is used for the lookup.
-- p_min_columns and
-- p_max_columns:       Used to check if the SQL statement complies to the number
--                      of required columns.
-- p_component_name:    The name of the page item or report column, ... which is
--                      used in case an error has to be displayed.
-- p_display_column_no: Column which should be returned from the SQL statement.
--                      Has to be in range of p_min_column and p_max_column.
-- p_search_column_no:  Column which should be used to restrict the SQL statement.
--                      Has to be in range of p_min_column and p_max_column.
-- p_search_value_list: Array of values which should be looked up.
-- p_display_extra:     If set to TRUE and a value isn't found, the search value
--                      will be added to the result instead.
--==============================================================================
function get_display_data (
    p_sql_statement      in varchar2,
    p_min_columns        in number,
    p_max_columns        in number,
    p_component_name     in varchar2,
    p_display_column_no  in binary_integer default 1,
    p_search_column_no   in binary_integer default 2,
    p_search_value_list  in wwv_flow_global.vc_arr2,
    p_display_extra      in boolean        default true,
    p_support_legacy_lov in boolean        default false /* for internal use only! */ )
    return wwv_flow_global.vc_arr2;
--
--==============================================================================
-- Opens a sql cursor and returns useful information about the SQL statement
-- in a record structure. Like used bind variables, column information, ...
--
-- p_sql_statement:  SQL statement which should be executed.
-- p_min_columns and
-- p_max_columns:    Used to check if the SQL statement complies to the number
--                   of required columns.
-- p_data_type_list: If provided checks that the data type for each column
--                   matches to the specified data type in the array.
--                   Use the constants c_data_type_* for available data types.
--                   Note: This parameter should be used in combination with
--                         get_data2.
-- p_component_name: The name of the page item or report column, ... which is
--                   used in case an error has to be displayed.
--
-- Note: Always call free_sql_handler after you are done reading data. Don't
--       forget to add it to the exception handler as well to release the cursor!
--==============================================================================
function get_sql_handler (
    p_sql_statement  in varchar2,
    p_min_columns    in number,
    p_max_columns    in number,
    p_data_type_list in wwv_flow_global.vc_arr2 default c_empty_data_type_list,
    p_component_name in varchar2 )
    return t_sql_handler;
--
--==============================================================================
-- Closes the open cursor created by get_sql_handler.
--
-- p_sql_handler: Record returned by get_sql_handler.
--==============================================================================
procedure free_sql_handler (
    p_sql_handler in out nocopy t_sql_handler );
--
--==============================================================================
-- Creates and parses a SQL statement based on p_search_type and p_max_row.
-- The procedure also already binds all page item bind variables.
-- Call get_data afterwards to get the actual data.
--
-- p_sql_handler:      Record returned by get_sql_handler.
-- p_search_type:      Use one of the c_search_* constants.
-- p_search_column_no: Column which should be used to restrict the SQL statement.
--                     Has to be in range of p_min_column and p_max_column.
-- p_first_row:        Skips all rows before the specified row. Can be used for
--                     pagination.
-- p_max_rows:         Limits the number of returned rows.
--
-- Note: get_sql_handler has to be called before this call.
--==============================================================================
procedure prepare_query (
    p_sql_handler      in t_sql_handler,
    p_search_type      in varchar2       default null,
    p_search_column_no in binary_integer default 2,
    p_first_row        in number         default null,
    p_max_rows         in number         default null );
--
--==============================================================================
-- Converts the search string in uppercase if it's a case insensitive search.
--
-- p_search_type:   Use one of the c_search_* constants.
-- p_search_string: Search string.
--==============================================================================
function get_search_string (
    p_search_type   in varchar2,
    p_search_string in varchar2 )
    return varchar2;
--
--==============================================================================
-- Executes the query restricted by search string (optional) and returns the
-- values for each column.
-- Note: All column values are returned as a string, independent of there
--       data type!
--
-- p_sql_handler:      Record returned by get_sql_handler.
-- p_search_column_no: Column which should be used to restrict the SQL statement.
-- p_search_string:    The query is restricted by this value.
--
-- Note: prepare_query has to be called before!
--==============================================================================
function get_data (
    p_sql_handler      in t_sql_handler,
    p_search_column_no in binary_integer default 2,
    p_search_string    in varchar2       default null )
    return t_column_value_list;
--
--==============================================================================
-- Executes the query restricted by search string (optional) and returns the
-- values for each column. This is a more advanced version of get_data, because
-- it returns the column values with there original data types.
--
-- p_sql_handler:      Record returned by get_sql_handler.
-- p_search_column_no: Column which should be used to restrict the SQL statement.
-- p_search_string:    The query is restricted by this value.
--
-- Note: prepare_query has to be called before!
--==============================================================================
function get_data2 (
    p_sql_handler      in t_sql_handler,
    p_search_column_no in binary_integer default 2,
    p_search_string    in varchar2       default null )
    return t_column_value_list2;
--
--==============================================================================
-- Gets the display (lookup) values for the values specified in p_search_value_list.
--
-- p_sql_handler:       Record returned by get_sql_handler.
-- p_display_column_no: Column which should be returned from the SQL statement.
--                      Has to be in range of p_min_column and p_max_column.
-- p_search_column_no:  Column which should be used to restrict the SQL statement.
--                      Has to be in range of p_min_column and p_max_column.
-- p_search_value_list: Array of values which should be looked up.
-- p_display_extra:     If set to TRUE and a value isn't found, the search value
--                      will be added to the result instead.
--
-- Note: get_sql_handler has to be called before!
--       prepare_query will be called by this function.
--==============================================================================
function get_display_data (
    p_sql_handler        in t_sql_handler,
    p_display_column_no  in binary_integer default 1,
    p_search_column_no   in binary_integer default 2,
    p_search_value_list  in wwv_flow_global.vc_arr2,
    p_display_extra      in boolean        default true )
    return wwv_flow_global.vc_arr2;
--
--==============================================================================
-- Executes a PL/SQL expression and returns the result.
--
-- p_plsql_expression: PL/SQL expression which returns string.
--==============================================================================
function get_plsql_expression_result (
    p_plsql_expression in varchar2 )
    return varchar2;
--
--==============================================================================
-- Executes a PL/SQL function code block and returns the result.
--
-- p_plsql_function: PL/SQL function which returns string.
--                   For example:
--                   declare
--                       l_test varchar2(10);
--                   begin
--                       -- do something
--                       return l_test;
--                   end;
--==============================================================================
function get_plsql_function_result (
    p_plsql_function in varchar2 )
    return varchar2;
--
--==============================================================================
-- Executes a PL/SQL code block.
--==============================================================================
procedure execute_plsql_code (
    p_plsql_code in varchar2 );
--
--==============================================================================
-- Function returns true if the passed build option, authorization and
-- condition are ok to display/process/use this component.
--==============================================================================
function is_component_used (
    p_build_option_id         in number   default null,
    p_authorization_scheme_id in varchar2,
    p_condition_type          in varchar2,
    p_condition_expression1   in varchar2,
    p_condition_expression2   in varchar2,
    p_component               in varchar2 default null )
    return boolean;
--
--==============================================================================
-- Writes the data of the page item meta data into the HTTP buffer.
--==============================================================================
procedure debug_page_item (
    p_plugin    in wwv_flow_plugin.t_plugin,
    p_page_item in wwv_flow_plugin.t_page_item );
--
procedure debug_page_item (
    p_plugin              in wwv_flow_plugin.t_plugin,
    p_page_item           in wwv_flow_plugin.t_page_item,
    p_value               in varchar2,
    p_is_readonly         in boolean,
    p_is_printer_friendly in boolean );
--
--==============================================================================
-- Writes the data of the region meta data into the HTTP buffer.
--==============================================================================
procedure debug_region (
    p_plugin in wwv_flow_plugin.t_plugin,
    p_region in wwv_flow_plugin.t_region );
--
procedure debug_region (
    p_plugin              in wwv_flow_plugin.t_plugin,
    p_region              in wwv_flow_plugin.t_region,
    p_is_printer_friendly in boolean );
--
--==============================================================================
-- Writes the data of the dynamic action meta data into the HTTP buffer.
--==============================================================================
procedure debug_dynamic_action (
    p_plugin         in wwv_flow_plugin.t_plugin,
    p_dynamic_action in wwv_flow_plugin.t_dynamic_action );
--
--==============================================================================
-- Writes the data of the process meta data into the HTTP buffer.
--==============================================================================
procedure debug_process (
    p_plugin  in wwv_flow_plugin.t_plugin,
    p_process in wwv_flow_plugin.t_process );
--
end wwv_flow_plugin_util;
/

