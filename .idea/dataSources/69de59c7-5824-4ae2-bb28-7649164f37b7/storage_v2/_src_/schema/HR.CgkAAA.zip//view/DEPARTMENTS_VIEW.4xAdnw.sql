create view DEPARTMENTS_VIEW as
select department_id,department_name from departments
/

