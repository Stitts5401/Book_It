create trigger SP_USER_ID_SEQ
    before insert
    on T_USER
    for each row
begin
      select sp_id_seq.nextval
        into :new.user_id
        from dual;
    end;
/

