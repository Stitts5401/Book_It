create trigger T_AUTH_SEQ
    before insert
    on T_AUTH_USER_GROUP
    for each row
begin
      select t_auth_id_seq.nextval
        into :new.AUTH_USER_GROUP_ID
        from dual;
    end;
/

