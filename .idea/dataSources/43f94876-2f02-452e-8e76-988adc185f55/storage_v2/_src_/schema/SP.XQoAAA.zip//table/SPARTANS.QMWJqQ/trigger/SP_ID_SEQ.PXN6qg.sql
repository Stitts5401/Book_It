create trigger SP_ID_SEQ
    before insert
    on SPARTANS
    for each row
begin
      select sp_id_seq.nextval
        into :new.spartan_id
        from dual;
    end;
/

